F250 — TRAP STREET
==================

You have been given sensor data from a Cowrie SSH honeypot operated by
The Machine on behalf of the Northern Lights programme.

The sensor ran for approximately 70 days. Most of what it caught is
automated noise — bots looking for forgotten cameras, default credentials,
abandoned routers. The sensor logs it all.

But one session is different.

A visitor came in quietly. They knew where to look. They took something
that was not meant for them — a file seeded specifically to be taken.

The file was a canary. When the visitor opened it, it told us where they
were.

Find the visitor's session in the logs.
Recover the canary file they downloaded.
Open it. Follow what it contains.

CONTENTS
--------
logs/        cowrie.json* — full session event logs (JSON, one event per line)
downloads/   files downloaded by sessions (SHA256-named)
tty/         raw TTY recordings (binary, use 'cowrie playlog' or strings)

FLAG FORMAT: number{...}

  — THE MACHINE
