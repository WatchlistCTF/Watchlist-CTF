"""Tests for artifact endpoints."""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock

from app.main import app

client = TestClient(app)


def test_health():
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"


def test_list_artifacts_no_config(monkeypatch):
    monkeypatch.setenv("RELAY_ARTIFACTS", "")
    resp = client.get("/artifacts/")
    assert resp.status_code in (200, 503)


@patch("app.routers.artifacts.s3_svc.list_artifacts")
def test_list_artifacts_success(mock_list):
    mock_list.return_value = [
        {"key": "media/relay-cam-0419.jpg", "size_bytes": 184320,
         "last_modified": "2024-03-31T14:00:00+00:00", "etag": "abc123"}
    ]
    with patch("app.routers.artifacts.settings") as mock_settings:
        mock_settings.relay_artifacts = "https://nl-relay-artifacts-7c2a.s3.us-east-2.amazonaws.com/"
        resp = client.get("/artifacts/")
    assert resp.status_code == 200
    data = resp.json()
    assert data["count"] == 1
    assert data["artifacts"][0]["key"] == "media/relay-cam-0419.jpg"


@patch("app.routers.artifacts.s3_svc.validate_checksums")
def test_validate_artifacts(mock_validate):
    mock_validate.return_value = [
        {"key": "media/relay-cam-0419.jpg", "status": "ok",
         "expected": "abc123", "actual": "abc123", "match": True}
    ]
    with patch("app.routers.artifacts.settings") as mock_settings:
        mock_settings.relay_artifacts = "https://nl-relay-artifacts-7c2a.s3.us-east-2.amazonaws.com/"
        resp = client.post(
            "/artifacts/validate?node_id=relay-4cf34e",
            json={"manifest": [{"key": "media/relay-cam-0419.jpg", "sha256": "abc123"}]}
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] == 1
    assert data["failures"] == 0
