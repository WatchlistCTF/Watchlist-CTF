"""Tests for relay node endpoints."""

import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_list_relays():
    resp = client.get("/relays/")
    assert resp.status_code == 200
    data = resp.json()
    assert "nodes" in data
    assert data["count"] == len(data["nodes"])


def test_list_relays_filter_status():
    resp = client.get("/relays/?status=decommissioned")
    assert resp.status_code == 200
    nodes = resp.json()["nodes"]
    assert all(n["status"] == "decommissioned" for n in nodes)


def test_list_relays_filter_region():
    resp = client.get("/relays/?region=us-east-2")
    assert resp.status_code == 200
    nodes = resp.json()["nodes"]
    assert all(n["region"] == "us-east-2" for n in nodes)


def test_get_relay_known():
    resp = client.get("/relays/relay-4cf34e")
    assert resp.status_code == 200
    data = resp.json()
    assert data["node_id"] == "relay-4cf34e"
    assert data["status"] == "decommissioned"


def test_get_relay_quarantined():
    resp = client.get("/relays/relay-a3f819")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "quarantined"


def test_get_relay_not_found():
    resp = client.get("/relays/relay-000000")
    assert resp.status_code == 404


def test_get_relay_hold():
    resp = client.get("/relays/proc-node-9f2a")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "hold"
    assert data["decom_date"] is None
