# nl-relay-tools

Internal FastAPI service for Northern Lights relay node artifact management and monitoring.

## Overview

`nl-relay-tools` provides a REST API for:
- Listing and syncing relay capture artifacts to the artifact store
- Validating artifact checksums against a manifest
- Monitoring relay node status across the estate

## Requirements

- Python 3.11+
- AWS credentials with `s3:ListBucket` and `s3:GetObject` on the artifact store
- (Optional) Slack webhook for sync notifications

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env with your values
```

## Running

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

API docs available at `http://localhost:8000/docs`

## API Reference

### Health

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Service health check |

### Artifacts

| Method | Path | Description |
|--------|------|-------------|
| GET | `/artifacts/` | List all artifacts in the store |
| POST | `/artifacts/sync` | Upload a file to the artifact store |
| POST | `/artifacts/validate` | Validate checksums against a manifest |
| GET | `/artifacts/manifest` | Get the current artifact manifest |

### Relays

| Method | Path | Description |
|--------|------|-------------|
| GET | `/relays/` | List all relay nodes (filterable by status, region) |
| GET | `/relays/{node_id}` | Get relay node details |
| GET | `/relays/{node_id}/artifacts` | List artifacts for a specific relay node |

## Configuration

See `.env.example` for all available environment variables.

## Testing

```bash
pytest tests/ -v
```

## Notes

- Artifact store requires anonymous `s3:ListBucket` and `s3:GetObject`
- If `RELAY_ARTIFACTS` is not set, artifact endpoints return 503
- Slack notifications are optional — omit `RELAY_SLACK_WEBHOOK` to disable
