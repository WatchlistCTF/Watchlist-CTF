#!/usr/bin/env bash
# =============================================================================
# nl-relay-tools — git history builder
# Run this ONCE inside an empty directory.
# Creates 35 commits across July 2026 with realistic timestamps.
#
# Usage:
#   mkdir nl-relay-repo && cd nl-relay-repo
#   bash /path/to/build_history.sh
#   git push origin main
#
# Before running:
#   1. Create a GitHub personal access token for decima-cloud-ui:
#      GitHub (logged in as decima-cloud-ui) → Settings → Developer Settings
#      → Personal access tokens → Tokens (classic) → Generate new token
#      → Scopes: repo (full) → copy the token
#   2. Set GITHUB_TOKEN below OR export it before running:
#      export GITHUB_TOKEN="ghp_xxxxxxxxxxxx"
# =============================================================================

set -e

# ── CONFIG ────────────────────────────────────────────────────────────────────
GIT_USER="decima-cloud"
GIT_EMAIL="318229493+decima-cloud-ui@users.noreply.github.com"
REPO_URL="https://github.com/decima-cloud/nl-relay-tools.git"

# GitHub personal access token for decima-cloud-ui
# Set via env var: export GITHUB_TOKEN="ghp_xxxxxxxxxxxx"
# Or paste directly here (remove before sharing):
GITHUB_TOKEN="${GITHUB_TOKEN:-}"

# S3 URLs — staging (dead decoy) then production (live bucket)
S3_STAGING="https://nl-relay-staging-4f2a.s3.us-east-2.amazonaws.com/"
S3_PROD="https://nl-relay-artifacts-7c2a.s3.us-east-2.amazonaws.com/"

# Dead decoy secrets — split to avoid scanner false positives in the script itself
# (the actual secret strings are embedded into .env file commits, not stored here as-is)
_SW_A="hooks.slack.com/services"
_SW_B="T02KX9A4N/B04MR2PLQ8F"
_SW_C="xK9mNpQr7sVwL3hJdE2cYbRt"
SLACK_WEBHOOK="https://${_SW_A}/${_SW_B}/${_SW_C}"

_SD_A="5a8f2e1c3b4d6789@o492847"
_SD_B="ingest.sentry.io/4823916"
SENTRY_DSN="https://${_SD_A}.${_SD_B}"

_AK_A="AKIAIOSFODNN"
_AK_B="7EXAMPLE3"
AWS_KEY="${_AK_A}${_AK_B}"

# ── GIT INIT + REMOTE ────────────────────────────────────────────────────────
if [ ! -d ".git" ]; then
    echo "[*] Initialising git repository..."
    git init
    git checkout -b main
else
    echo "[*] Git repository already initialised"
fi

# Set remote — use token-authenticated URL if token is provided
if [ -n "$GITHUB_TOKEN" ]; then
    REMOTE_URL="https://${GITHUB_TOKEN}@github.com/decima-cloud/nl-relay-tools.git"
else
    REMOTE_URL="$REPO_URL"
fi

if git remote get-url origin &>/dev/null; then
    git remote set-url origin "$REMOTE_URL"
    echo "[*] Remote 'origin' updated"
else
    git remote add origin "$REMOTE_URL"
    echo "[*] Remote 'origin' added"
fi

# ── GIT CONFIG (local — does not affect global git config) ───────────────────
git config user.name  "$GIT_USER"
git config user.email "$GIT_EMAIL"

# Store credentials for the session (avoids repeated password prompts)
git config credential.helper store

echo "[*] Git configured as $GIT_USER <$GIT_EMAIL>"
echo "[*] Remote: $REPO_URL"
echo ""

# ── COMMIT HELPER ─────────────────────────────────────────────────────────────
commit() {
  local msg="$1"
  local ts="$2"   # e.g. "2026-07-01T09:14:00+05:30"
  git add -A
  GIT_AUTHOR_DATE="$ts" GIT_COMMITTER_DATE="$ts" \
    git commit -m "$msg" --allow-empty-message
  echo "  [+] $ts  $msg"
}

# =============================================================================
# WEEK 1 — Jul 1-5: Project scaffold, no secrets
# =============================================================================
echo
echo "── Week 1: Project scaffold ──────────────────────────────────────────"

# Jul 1 09:14 — initial scaffold
cat > .gitignore << 'EOF'
.env
__pycache__/
*.py[cod]
*.egg-info/
.venv/
venv/
env/
dist/
build/
.pytest_cache/
.mypy_cache/
*.log
*.sqlite
.DS_Store
build_history.sh
secrets.conf
EOF

mkdir -p app/routers app/services tests
touch app/__init__.py app/routers/__init__.py app/services/__init__.py tests/__init__.py

cat > app/main.py << 'EOF'
"""Northern Lights Relay Tools — FastAPI service."""
from fastapi import FastAPI

app = FastAPI(
    title="Northern Lights Relay Tools",
    description="Internal relay node artifact management.",
    version="0.1.0",
)

@app.get("/health")
async def health():
    return {"status": "ok"}
EOF

commit "feat: initial FastAPI scaffold" "2026-07-01T09:14:00+05:30"

# Jul 1 14:32 — requirements
cat > requirements.txt << 'EOF'
fastapi==0.115.0
uvicorn[standard]==0.32.0
pydantic==2.9.2
pydantic-settings==2.5.2
boto3==1.35.36
python-multipart==0.0.12
httpx==0.27.2
pytest==8.3.3
pytest-asyncio==0.24.0
sentry-sdk[fastapi]==2.16.0
EOF

commit "chore: add requirements.txt" "2026-07-01T14:32:00+05:30"

# Jul 2 10:08 — config module
cat > app/config.py << 'EOF'
"""Application configuration."""
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    app_env: str = "development"
    log_level: str = "INFO"
    relay_artifacts: str = ""

    class Config:
        env_file = ".env"
        extra = "ignore"

@lru_cache()
def get_settings():
    return Settings()

settings = get_settings()
EOF

commit "feat: add config module with env var loading" "2026-07-02T10:08:00+05:30"

# Jul 2 15:45 — health endpoint improved
cat > app/main.py << 'EOF'
"""Northern Lights Relay Tools — FastAPI service."""
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Northern Lights Relay Tools",
    description="Internal relay node artifact management and monitoring.",
    version="0.2.0",
    docs_url="/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/health", tags=["Health"])
async def health():
    return {"status": "ok", "env": settings.app_env}
EOF

commit "feat: improve health endpoint with env info" "2026-07-02T15:45:00+05:30"

# Jul 3 11:22 — artifact router skeleton
cat > app/routers/artifacts.py << 'EOF'
"""Artifact management endpoints — skeleton."""
from fastapi import APIRouter, HTTPException
from app.config import settings

router = APIRouter()

@router.get("/", summary="List artifacts")
async def list_artifacts():
    if not settings.relay_artifacts:
        raise HTTPException(status_code=503, detail="Artifact store not configured")
    return {"store": settings.relay_artifacts, "artifacts": []}
EOF

commit "feat: add artifact router skeleton" "2026-07-03T11:22:00+05:30"

# Jul 3 16:50 — relay router skeleton
cat > app/routers/relays.py << 'EOF'
"""Relay node status endpoints — skeleton."""
from fastapi import APIRouter, HTTPException

router = APIRouter()
NODES: list[dict] = []

@router.get("/", summary="List relay nodes")
async def list_relays():
    return {"count": len(NODES), "nodes": NODES}

@router.get("/{node_id}", summary="Get relay node")
async def get_relay(node_id: str):
    node = next((n for n in NODES if n["node_id"] == node_id), None)
    if not node:
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found")
    return node
EOF

commit "feat: add relay node router skeleton" "2026-07-03T16:50:00+05:30"

# Jul 4 09:33 — wire routers into main
cat > app/main.py << 'EOF'
"""Northern Lights Relay Tools — FastAPI service."""
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import artifacts, relays

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Northern Lights Relay Tools",
    description="Internal relay node artifact management and monitoring.",
    version="0.3.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.include_router(artifacts.router, prefix="/artifacts", tags=["Artifacts"])
app.include_router(relays.router,    prefix="/relays",    tags=["Relays"])

@app.get("/health", tags=["Health"])
async def health():
    return {"status": "ok", "env": settings.app_env}
EOF

commit "feat: wire artifact and relay routers into app" "2026-07-04T09:33:00+05:30"

# Jul 5 13:17 — fix import error found in testing
cat >> app/routers/__init__.py << 'EOF'
# routers package
EOF

commit "fix: correct router package import" "2026-07-05T13:17:00+05:30"

# =============================================================================
# WEEK 2 — Jul 6-10: S3 integration, STAGING URL added
# =============================================================================
echo
echo "── Week 2: S3 integration (staging) ────────────────────────────────"

# Jul 6 09:55 — S3 service wrapper
cat > app/services/s3.py << 'EOF'
"""S3 service — artifact store operations."""
import boto3, hashlib, logging
from botocore import exceptions as botocore_exc
from botocore.config import Config
from urllib.parse import urlparse
from app.config import settings

logger = logging.getLogger(__name__)

BOTO_CONFIG = Config(connect_timeout=5, read_timeout=10,
                     retries={"max_attempts": 2, "mode": "standard"})

def _parse_bucket(url: str) -> tuple[str, str]:
    parsed = urlparse(url)
    parts  = parsed.netloc.split(".")
    bucket = parts[0]
    region = parts[2] if len(parts) >= 4 and parts[1] == "s3" else "us-east-2"
    return bucket, region

def _client(region=None):
    kwargs = {"config": BOTO_CONFIG, "region_name": region or settings.relay_aws_region}
    if settings.relay_aws_key:
        kwargs["aws_access_key_id"]     = settings.relay_aws_key
        kwargs["aws_secret_access_key"] = settings.relay_aws_secret
    return boto3.client("s3", **kwargs)

def list_artifacts(url: str) -> list[dict]:
    bucket, region = _parse_bucket(url)
    s3 = _client(region)
    objects = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket):
            for obj in page.get("Contents", []):
                objects.append({
                    "key":           obj["Key"],
                    "size_bytes":    obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                    "etag":          obj["ETag"].strip('"'),
                })
    except botocore_exc.ClientError as exc:
        logger.error(f"S3 list failed: {exc}")
        raise
    return objects
EOF

# Add .env with staging URL
cat > .env << EOF
APP_ENV=development
LOG_LEVEL=INFO
RELAY_ARTIFACTS=$S3_STAGING
EOF

commit "feat: add S3 service wrapper with artifact listing" "2026-07-06T09:55:00+05:30"

# Jul 6 17:30 — .env.example
cat > .env.example << 'EOF'
APP_ENV=development
LOG_LEVEL=INFO
RELAY_ARTIFACTS=https://your-bucket.s3.us-east-2.amazonaws.com/
RELAY_SLACK_WEBHOOK=
RELAY_SENTRY_DSN=
RELAY_AWS_KEY=
RELAY_AWS_SECRET=
RELAY_AWS_REGION=us-east-2
EOF

commit "chore: add .env.example with required variables" "2026-07-06T17:30:00+05:30"

# Jul 7 10:44 — wire S3 into artifact router
cat > app/routers/artifacts.py << 'EOF'
"""Artifact management endpoints."""
from fastapi import APIRouter, HTTPException
from app.config import settings
from app.services import s3 as s3_svc
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

def _require_artifacts():
    if not settings.relay_artifacts:
        raise HTTPException(status_code=503, detail="Artifact store not configured")

@router.get("/", summary="List artifacts in the store")
async def list_artifacts():
    _require_artifacts()
    try:
        objects = s3_svc.list_artifacts(settings.relay_artifacts)
        return {"store": settings.relay_artifacts, "count": len(objects), "artifacts": objects}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))
EOF

commit "feat: integrate S3 listing into artifact endpoint" "2026-07-07T10:44:00+05:30"

# Jul 8 14:20 — handle empty bucket gracefully
cat >> app/services/s3.py << 'EOF'

def validate_connection(url: str) -> bool:
    """Quick reachability check (no credentials needed for public buckets)."""
    import urllib.request
    try:
        req = urllib.request.Request(url, method="HEAD")
        urllib.request.urlopen(req, timeout=5)
        return True
    except Exception as exc:
        if hasattr(exc, "code") and exc.code in (403, 301, 302):
            return True
        return False
EOF

commit "fix: handle empty bucket response gracefully" "2026-07-08T14:20:00+05:30"

# Jul 9 09:10 — startup validation
cat > app/main.py << 'EOF'
"""Northern Lights Relay Tools — FastAPI service."""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import artifacts, relays
from app.services.s3 import validate_connection

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Starting nl-relay-tools [{settings.app_env}]")
    if settings.relay_artifacts:
        if validate_connection(settings.relay_artifacts):
            logger.info("Artifact store connection validated")
        else:
            logger.warning("Artifact store unreachable — degraded mode")
    else:
        logger.warning("RELAY_ARTIFACTS not set")
    yield
    logger.info("Shutting down")

app = FastAPI(
    title="Northern Lights Relay Tools",
    description="Internal relay node artifact management and monitoring.",
    version="0.4.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["GET", "POST"], allow_headers=["*"])
app.include_router(artifacts.router, prefix="/artifacts", tags=["Artifacts"])
app.include_router(relays.router,    prefix="/relays",    tags=["Relays"])

@app.get("/health", tags=["Health"])
async def health():
    return {"status": "ok", "env": settings.app_env,
            "artifact_store": bool(settings.relay_artifacts)}
EOF

commit "feat: add startup artifact store validation" "2026-07-09T09:10:00+05:30"

# Jul 10 16:05 — fix S3 region handling
cat >> app/config.py << 'EOF'

# AWS
relay_aws_region: str = "us-east-2"
relay_aws_key:    str = ""
relay_aws_secret: str = ""
EOF

commit "fix: add AWS region config to settings" "2026-07-10T16:05:00+05:30"

# =============================================================================
# WEEK 3 — Jul 11-15: Switch to production S3 URL
# =============================================================================
echo
echo "── Week 3: Switch to production S3 ─────────────────────────────────"

# Jul 11 08:47 — SWITCH TO PRODUCTION S3 (THE KEY COMMIT)
cat > .env << EOF
APP_ENV=development
LOG_LEVEL=INFO
RELAY_ARTIFACTS=$S3_PROD
EOF

commit "chore: switch artifact store to production endpoint" "2026-07-11T08:47:00+05:30"

# Jul 11 15:33 — S3 upload function
cat >> app/services/s3.py << 'EOF'

def upload_artifact(url: str, local_path: str, key: str) -> dict:
    bucket, region = _parse_bucket(url)
    s3  = _client(region)
    sha = hashlib.sha256(open(local_path, "rb").read()).hexdigest()
    try:
        s3.upload_file(local_path, bucket, key,
                       ExtraArgs={"Metadata": {"sha256": sha}})
        logger.info(f"Uploaded {local_path} -> s3://{bucket}/{key}")
        return {"key": key, "sha256": sha, "bucket": bucket}
    except botocore_exc.ClientError as exc:
        logger.error(f"Upload failed: {exc}")
        raise
EOF

commit "feat: add artifact upload with progress tracking" "2026-07-11T15:33:00+05:30"

# Jul 12 10:55 — sync endpoint
cat >> app/routers/artifacts.py << 'EOF'

from fastapi import UploadFile, File
from pydantic import BaseModel
import tempfile, os
from app.services import s3 as s3_svc

class SyncResponse(BaseModel):
    uploaded: int
    errors:   int
    keys:     list[str]

@router.post("/sync", summary="Upload a capture file", response_model=SyncResponse)
async def sync_artifact(node_id: str, file: UploadFile = File(...)):
    _require_artifacts()
    key = f"media/{file.filename}"
    try:
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(await file.read())
            tmp_path = tmp.name
        result = s3_svc.upload_artifact(settings.relay_artifacts, tmp_path, key)
        return SyncResponse(uploaded=1, errors=0, keys=[result["key"]])
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if "tmp_path" in locals() and os.path.exists(tmp_path):
            os.unlink(tmp_path)
EOF

commit "feat: add artifact sync endpoint" "2026-07-12T10:55:00+05:30"

# Jul 13 14:08 — manifest endpoint
cat >> app/routers/artifacts.py << 'EOF'

@router.get("/manifest", summary="Get current artifact manifest")
async def get_manifest():
    _require_artifacts()
    objects = s3_svc.list_artifacts(settings.relay_artifacts)
    manifest = [{"key": o["key"], "size_bytes": o["size_bytes"], "sha256": ""} for o in objects]
    return {"count": len(manifest), "manifest": manifest}
EOF

commit "feat: add artifact manifest endpoint" "2026-07-13T14:08:00+05:30"

# Jul 14 09:30 — fix S3 connection timeout
cat > app/services/s3.py << 'EOF'
"""S3 service — artifact store operations."""
import boto3, hashlib, logging, urllib.request
from botocore import exceptions as botocore_exc
from botocore.config import Config
from urllib.parse import urlparse
from app.config import settings

logger = logging.getLogger(__name__)

BOTO_CONFIG = Config(
    connect_timeout=5,
    read_timeout=10,
    retries={"max_attempts": 3, "mode": "adaptive"},
)

def _parse_bucket(url: str) -> tuple[str, str]:
    parsed = urlparse(url)
    parts  = parsed.netloc.split(".")
    bucket = parts[0]
    region = parts[2] if len(parts) >= 4 and parts[1] == "s3" else "us-east-2"
    return bucket, region

def _client(region=None):
    kwargs = {"config": BOTO_CONFIG, "region_name": region or settings.relay_aws_region}
    if settings.relay_aws_key:
        kwargs["aws_access_key_id"]     = settings.relay_aws_key
        kwargs["aws_secret_access_key"] = settings.relay_aws_secret
    return boto3.client("s3", **kwargs)

def validate_connection(url: str) -> bool:
    try:
        req = urllib.request.Request(url, method="HEAD")
        urllib.request.urlopen(req, timeout=5)
        return True
    except Exception as exc:
        if hasattr(exc, "code") and exc.code in (403, 301, 302):
            return True
        return False

def list_artifacts(url: str) -> list[dict]:
    bucket, region = _parse_bucket(url)
    s3 = _client(region)
    objects = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket):
            for obj in page.get("Contents", []):
                objects.append({
                    "key":           obj["Key"],
                    "size_bytes":    obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                    "etag":          obj["ETag"].strip('"'),
                })
    except botocore_exc.ClientError as exc:
        logger.error(f"S3 list failed: {exc}")
        raise
    return objects

def upload_artifact(url: str, local_path: str, key: str) -> dict:
    bucket, region = _parse_bucket(url)
    s3  = _client(region)
    sha = hashlib.sha256(open(local_path, "rb").read()).hexdigest()
    try:
        s3.upload_file(local_path, bucket, key,
                       ExtraArgs={"Metadata": {"sha256": sha}})
        logger.info(f"Uploaded -> s3://{bucket}/{key}")
        return {"key": key, "sha256": sha, "bucket": bucket}
    except botocore_exc.ClientError as exc:
        logger.error(f"Upload failed: {exc}")
        raise

def validate_checksums(url: str, manifest: list[dict]) -> list[dict]:
    bucket, region = _parse_bucket(url)
    s3 = _client(region)
    results = []
    for entry in manifest:
        key, expected = entry["key"], entry.get("sha256", "")
        try:
            head   = s3.head_object(Bucket=bucket, Key=key)
            actual = head.get("Metadata", {}).get("sha256", "")
            match  = actual == expected if expected else None
            results.append({"key": key, "expected": expected, "actual": actual,
                             "match": match, "status": "ok" if match else "mismatch"})
        except botocore_exc.ClientError as exc:
            results.append({"key": key, "status": "missing", "error": str(exc)})
    return results
EOF

commit "fix: handle S3 connection timeout with retry" "2026-07-14T09:30:00+05:30"

# Jul 15 17:22 — validate keys before upload
cat >> app/routers/artifacts.py << 'EOF'

import re
VALID_KEY = re.compile(r'^[a-zA-Z0-9/\-_.]+$')

def _validate_key(key: str):
    if not VALID_KEY.match(key):
        raise HTTPException(status_code=400, detail=f"Invalid artifact key: {key}")
EOF

commit "fix: validate artifact keys before S3 upload" "2026-07-15T17:22:00+05:30"

# =============================================================================
# WEEK 4 — Jul 16-20: Relay nodes + validation
# =============================================================================
echo
echo "── Week 4: Relay nodes + validation ────────────────────────────────"

# Jul 16 10:12 — relay data models
cat > app/routers/relays.py << 'EOF'
"""Relay node status endpoints."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class RelayStatus(BaseModel):
    node_id:      str
    type:         str
    region:       str
    status:       str
    last_contact: Optional[str]
    decom_date:   Optional[str]
    reason:       Optional[str]

RELAY_REGISTRY: dict[str, dict] = {
    "relay-4cf34e": {"node_id": "relay-4cf34e", "type": "relay", "region": "us-east-2",
                     "status": "decommissioned", "last_contact": "2024-03-31T14:07:22Z",
                     "decom_date": "2024-03-31", "reason": "scheduled"},
    "relay-7f3a2c": {"node_id": "relay-7f3a2c", "type": "relay", "region": "eu-west-1",
                     "status": "decommissioned", "last_contact": "2023-11-28T22:18:44Z",
                     "decom_date": "2023-11-28", "reason": "unscheduled"},
    "relay-141786": {"node_id": "relay-141786", "type": "relay", "region": "us-west-1",
                     "status": "decommissioned", "last_contact": "2024-01-15T08:31:19Z",
                     "decom_date": "2024-01-15", "reason": "directive-nl-2023-q4-07"},
    "relay-2b8e91": {"node_id": "relay-2b8e91", "type": "relay", "region": "us-central",
                     "status": "decommissioned", "last_contact": "2023-07-04T16:55:03Z",
                     "decom_date": "2023-07-04", "reason": "classified"},
    "relay-5d0e44": {"node_id": "relay-5d0e44", "type": "relay", "region": "us-east-1",
                     "status": "decommissioned", "last_contact": "2026-08-01T09:44:11Z",
                     "decom_date": "2026-08-01", "reason": "scheduled-retirement-q3-2026"},
    "relay-a3f819": {"node_id": "relay-a3f819", "type": "relay", "region": "us-east-2",
                     "status": "quarantined", "last_contact": "2023-02-11T11:00:47Z",
                     "decom_date": "2023-02-11", "reason": "security-incident"},
    "feed-arc-0c44": {"node_id": "feed-arc-0c44", "type": "archive-feed", "region": "us-central",
                      "status": "decommissioned", "last_contact": "2022-09-30T07:47:55Z",
                      "decom_date": "2022-09-30", "reason": "migrated-to-feed-secondary"},
    "feed-arc-3b1e": {"node_id": "feed-arc-3b1e", "type": "archive-feed", "region": "us-west-2",
                      "status": "decommissioned", "last_contact": "2022-06-14T19:03:22Z",
                      "decom_date": "2022-06-14", "reason": "upstream-disconnection"},
    "proc-node-9f2a": {"node_id": "proc-node-9f2a", "type": "processing", "region": "us-east-1",
                       "status": "hold", "last_contact": "2026-07-22T14:19:08Z",
                       "decom_date": None, "reason": "administrative-hold-pending-review"},
}

@router.get("/", summary="List all relay nodes")
async def list_relays(status: Optional[str] = None, region: Optional[str] = None):
    nodes = list(RELAY_REGISTRY.values())
    if status: nodes = [n for n in nodes if n["status"] == status]
    if region: nodes = [n for n in nodes if n["region"] == region]
    return {"count": len(nodes), "nodes": nodes}

@router.get("/{node_id}", summary="Get relay node details", response_model=RelayStatus)
async def get_relay(node_id: str):
    node = RELAY_REGISTRY.get(node_id)
    if not node:
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found")
    return node
EOF

commit "feat: add relay node data models and registry" "2026-07-16T10:12:00+05:30"

# Jul 17 14:33 — checksum validation endpoint
cat >> app/routers/artifacts.py << 'EOF'

class ValidateRequest(BaseModel):
    manifest: list[dict]

@router.post("/validate", summary="Validate artifact checksums")
async def validate_artifacts(node_id: str, body: ValidateRequest):
    _require_artifacts()
    results  = s3_svc.validate_checksums(settings.relay_artifacts, body.manifest)
    failures = [r["key"] for r in results if r.get("status") != "ok"]
    return {"node_id": node_id, "total": len(results),
            "ok": len(results) - len(failures), "failures": len(failures), "results": results}
EOF

commit "feat: add checksum validation against manifest" "2026-07-17T14:33:00+05:30"

# Jul 18 09:50 — per-relay artifact listing
cat >> app/routers/relays.py << 'EOF'

@router.get("/{node_id}/artifacts", summary="List artifacts for a relay node")
async def relay_artifacts(node_id: str):
    from app.config import settings
    from app.services import s3 as s3_svc
    if not RELAY_REGISTRY.get(node_id):
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found")
    if not settings.relay_artifacts:
        raise HTTPException(status_code=503, detail="Artifact store not configured")
    all_objs   = s3_svc.list_artifacts(settings.relay_artifacts)
    node_objs  = [o for o in all_objs if node_id in o["key"]]
    return {"node_id": node_id, "count": len(node_objs), "artifacts": node_objs}
EOF

commit "feat: add per-relay artifact listing endpoint" "2026-07-18T09:50:00+05:30"

# Jul 19 16:40 — fix typo in relay status enum
sed -i 's/"quarantined"/"quarantined"/' app/routers/relays.py
cat >> app/routers/relays.py << 'EOF'

# STATUS_VALUES kept for validation reference
STATUS_VALUES = ("decommissioned", "quarantined", "offline", "hold", "operational")
EOF

commit "fix: fix relay status enum reference" "2026-07-19T16:40:00+05:30"

# Jul 20 11:15 — update version
sed -i 's/version="0.4.0"/version="0.5.0"/' app/main.py
commit "chore: bump version to 0.5.0" "2026-07-20T11:15:00+05:30"

# =============================================================================
# WEEK 5 — Jul 21-25: Slack, Sentry, AWS key (dead decoys planted)
# =============================================================================
echo
echo "── Week 5: Notifications + observability ────────────────────────────"

# Jul 21 09:28 — Slack notification service
cat > app/services/notify.py << 'EOF'
"""Slack notification service."""
import logging, urllib.request, json
from app.config import settings

logger = logging.getLogger(__name__)

def _send(payload: dict) -> bool:
    if not settings.relay_slack_webhook:
        return False
    try:
        data = json.dumps(payload).encode()
        req  = urllib.request.Request(settings.relay_slack_webhook, data=data,
                                      headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status == 200
    except Exception as exc:
        logger.warning(f"Slack notification failed: {exc}")
        return False

def notify_sync_complete(node_id: str, count: int, errors: int = 0) -> bool:
    icon = ":white_check_mark:" if errors == 0 else ":warning:"
    return _send({"text": f"{icon} *Relay sync complete* — `{node_id}` — {count} artifacts"})

def notify_validation_failure(node_id: str, failures: list[str]) -> bool:
    items = "\n".join(f"• `{k}`" for k in failures[:10])
    return _send({"text": f":x: *Validation failed* — `{node_id}`\n{items}"})
EOF

# Add Slack webhook to .env
cat > .env << EOF
APP_ENV=development
LOG_LEVEL=INFO
RELAY_ARTIFACTS=$S3_PROD
RELAY_SLACK_WEBHOOK=$SLACK_WEBHOOK
RELAY_SLACK_CHANNEL=#relay-ops
EOF

commit "feat: add Slack notification service" "2026-07-21T09:28:00+05:30"

# Jul 22 14:55 — wire notifications into sync
sed -i '/from app.services import s3 as s3_svc/a from app.services.notify import notify_sync_complete, notify_validation_failure' app/routers/artifacts.py
commit "feat: notify Slack on sync completion and validation failure" "2026-07-22T14:55:00+05:30"

# Jul 23 10:30 — Sentry integration + AWS key added to .env
cat > app/config.py << EOF
"""Application configuration."""
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    app_env:               str = "development"
    log_level:             str = "INFO"
    relay_artifacts:       str = ""
    relay_slack_webhook:   str = ""
    relay_slack_channel:   str = "#relay-ops"
    relay_sentry_dsn:      str = ""
    relay_aws_key:         str = ""
    relay_aws_secret:      str = ""
    relay_aws_region:      str = "us-east-2"

    class Config:
        env_file = ".env"
        extra = "ignore"

@lru_cache()
def get_settings():
    return Settings()

settings = get_settings()
EOF

cat > .env << EOF
APP_ENV=development
LOG_LEVEL=INFO
RELAY_ARTIFACTS=$S3_PROD
RELAY_SLACK_WEBHOOK=$SLACK_WEBHOOK
RELAY_SLACK_CHANNEL=#relay-ops
RELAY_SENTRY_DSN=$SENTRY_DSN
RELAY_AWS_KEY=$AWS_KEY
RELAY_AWS_SECRET=
RELAY_AWS_REGION=us-east-2
EOF

commit "feat: add Sentry error tracking and AWS credential config" "2026-07-23T10:30:00+05:30"

# Jul 24 15:44 — wire Sentry into main
cat > app/main.py << 'EOF'
"""Northern Lights Relay Tools — FastAPI service."""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import artifacts, relays
from app.services.s3 import validate_connection

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger(__name__)

def _init_sentry():
    if settings.relay_sentry_dsn:
        import sentry_sdk
        sentry_sdk.init(dsn=settings.relay_sentry_dsn, traces_sample_rate=0.1)
        logger.info("Sentry initialised")

@asynccontextmanager
async def lifespan(app: FastAPI):
    _init_sentry()
    logger.info(f"Starting nl-relay-tools [{settings.app_env}]")
    if settings.relay_artifacts:
        if validate_connection(settings.relay_artifacts):
            logger.info("Artifact store connection validated")
        else:
            logger.warning("Artifact store unreachable — degraded mode")
    yield
    logger.info("Shutting down")

app = FastAPI(
    title="Northern Lights Relay Tools",
    description="Internal relay node artifact management and monitoring.",
    version="0.6.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["GET", "POST"], allow_headers=["*"])
app.include_router(artifacts.router, prefix="/artifacts", tags=["Artifacts"])
app.include_router(relays.router,    prefix="/relays",    tags=["Relays"])

@app.get("/health", tags=["Health"])
async def health():
    return {"status": "ok", "env": settings.app_env,
            "artifact_store": bool(settings.relay_artifacts)}
EOF

commit "feat: integrate Sentry on startup" "2026-07-24T15:44:00+05:30"

# Jul 25 11:08 — improve error responses
commit "fix: improve error response messages across routers" "2026-07-25T11:08:00+05:30"

# =============================================================================
# WEEK 6 — Jul 26-28: Tests + refactor
# =============================================================================
echo
echo "── Week 6: Tests + refactor ──────────────────────────────────────────"

# Jul 26 09:44 — artifact tests
cat > tests/test_artifacts.py << 'EOF'
"""Tests for artifact endpoints."""
from fastapi.testclient import TestClient
from unittest.mock import patch
from app.main import app

client = TestClient(app)

def test_health():
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"

def test_list_artifacts_no_config():
    resp = client.get("/artifacts/")
    assert resp.status_code in (200, 503)

@patch("app.routers.artifacts.s3_svc.list_artifacts")
def test_list_artifacts_success(mock_list):
    mock_list.return_value = [
        {"key": "media/relay-cam-0419.jpg", "size_bytes": 184320,
         "last_modified": "2024-03-31T14:00:00+00:00", "etag": "abc123"}
    ]
    with patch("app.routers.artifacts.settings") as ms:
        ms.relay_artifacts = "https://nl-relay-artifacts-7c2a.s3.us-east-2.amazonaws.com/"
        resp = client.get("/artifacts/")
    assert resp.status_code == 200
    assert resp.json()["count"] == 1
EOF

commit "test: add artifact endpoint tests" "2026-07-26T09:44:00+05:30"

# Jul 27 14:20 — relay tests
cat > tests/test_relays.py << 'EOF'
"""Tests for relay node endpoints."""
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_list_relays():
    resp = client.get("/relays/")
    assert resp.status_code == 200
    assert "nodes" in resp.json()

def test_list_relays_filter_status():
    resp = client.get("/relays/?status=decommissioned")
    assert all(n["status"] == "decommissioned" for n in resp.json()["nodes"])

def test_get_relay_known():
    resp = client.get("/relays/relay-4cf34e")
    assert resp.status_code == 200
    assert resp.json()["node_id"] == "relay-4cf34e"

def test_get_relay_not_found():
    resp = client.get("/relays/relay-000000")
    assert resp.status_code == 404
EOF

commit "test: add relay status endpoint tests" "2026-07-27T14:20:00+05:30"

# Jul 28 10:35 — refactor S3 service layer
commit "refactor: clean up S3 service layer and add type hints" "2026-07-28T10:35:00+05:30"

# Jul 28 16:50 — bump deps
sed -i 's/boto3==1.35.36/boto3==1.35.47/' requirements.txt
sed -i 's/fastapi==0.115.0/fastapi==0.115.2/' requirements.txt
commit "chore: bump dependencies to latest patch versions" "2026-07-28T16:50:00+05:30"

# =============================================================================
# WEEK 7 — Jul 29-31: Pre-release scrub (THE TELL)
# =============================================================================
echo
echo "── Week 7: Pre-release scrub ─────────────────────────────────────────"

# Jul 29 08:55 — handle missing env vars
cat >> app/main.py << 'EOF'

def _validate_config():
    missing = []
    if not settings.relay_artifacts:
        missing.append("RELAY_ARTIFACTS")
    if missing:
        import warnings
        warnings.warn(f"Missing env vars: {', '.join(missing)}", RuntimeWarning)
EOF

commit "fix: handle missing environment variables on startup" "2026-07-29T08:55:00+05:30"

# Jul 30 11:22 — remove internal references
commit "chore: remove internal relay node references from comments" "2026-07-30T11:22:00+05:30"

# Jul 30 15:40 — prep for open source
cat > README.md << 'READMEEOF'
# nl-relay-tools

Internal FastAPI service for Northern Lights relay node artifact management and monitoring.

## Overview

Provides a REST API for:
- Listing and syncing relay capture artifacts to the artifact store
- Validating artifact checksums against a manifest
- Monitoring relay node status across the estate

## Requirements

- Python 3.11+
- AWS credentials with s3:ListBucket and s3:GetObject on the artifact store

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## Running

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

API docs at http://localhost:8000/docs

## Testing

```bash
pytest tests/ -v
```
READMEEOF

commit "chore: prepare for open source release" "2026-07-30T15:40:00+05:30"

# Jul 31 09:17 — update docs
commit "docs: add API reference to README" "2026-07-31T09:17:00+05:30"

# Jul 31 14:30 — THE SCRUB (the tell)
cat > .env << 'EOF'
APP_ENV=production
LOG_LEVEL=INFO
RELAY_ARTIFACTS=__REDACTED__
EOF

commit "chore: scrub secrets before public release" "2026-07-31T14:30:00+05:30"

# =============================================================================
echo
echo "==================================================================="
echo "History built successfully."
echo ""
git log --oneline
echo ""
echo "Total commits: $(git rev-list --count HEAD)"
echo ""
echo "Next step:"
echo "  git push origin main"
echo "==================================================================="
