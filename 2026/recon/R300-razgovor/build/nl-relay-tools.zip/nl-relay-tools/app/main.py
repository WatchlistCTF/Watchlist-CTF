"""
Northern Lights Relay Tools — FastAPI service
Internal artifact management and relay node monitoring.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.routers import artifacts, relays
from app.services.s3 import validate_connection

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Starting nl-relay-tools [{settings.app_env}]")
    if settings.relay_artifacts:
        ok = validate_connection(settings.relay_artifacts)
        if ok:
            logger.info("Artifact store connection validated")
        else:
            logger.warning("Artifact store unreachable — running in degraded mode")
    else:
        logger.warning("RELAY_ARTIFACTS not configured — artifact endpoints unavailable")
    yield
    logger.info("Shutting down nl-relay-tools")


app = FastAPI(
    title="Northern Lights Relay Tools",
    description="Internal service for relay node artifact management and monitoring.",
    version="0.9.1",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.include_router(artifacts.router, prefix="/artifacts", tags=["Artifacts"])
app.include_router(relays.router, prefix="/relays", tags=["Relays"])


@app.get("/health", tags=["Health"])
async def health():
    return {
        "status": "ok",
        "env": settings.app_env,
        "artifact_store": bool(settings.relay_artifacts),
    }
