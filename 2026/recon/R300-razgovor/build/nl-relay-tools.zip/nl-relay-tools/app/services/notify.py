"""Slack notification service."""

import logging
import urllib.request
import json
from app.config import settings

logger = logging.getLogger(__name__)


def _send(payload: dict) -> bool:
    if not settings.relay_slack_webhook:
        logger.debug("Slack webhook not configured — skipping notification")
        return False
    try:
        data = json.dumps(payload).encode()
        req  = urllib.request.Request(
            settings.relay_slack_webhook,
            data=data,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status == 200
    except Exception as exc:
        logger.warning(f"Slack notification failed: {exc}")
        return False


def notify_sync_complete(node_id: str, count: int, errors: int = 0) -> bool:
    status = ":white_check_mark:" if errors == 0 else ":warning:"
    text   = (
        f"{status} *Relay sync complete* — `{node_id}`\n"
        f"Artifacts synced: *{count}*"
        + (f"\nErrors: *{errors}*" if errors else "")
    )
    return _send({"text": text, "channel": settings.relay_slack_channel})


def notify_validation_failure(node_id: str, failures: list[str]) -> bool:
    items = "\n".join(f"• `{k}`" for k in failures[:10])
    text  = (
        f":x: *Artifact validation failed* — `{node_id}`\n"
        f"Mismatched checksums:\n{items}"
        + (f"\n_...and {len(failures)-10} more_" if len(failures) > 10 else "")
    )
    return _send({"text": text, "channel": settings.relay_slack_channel})


def notify_node_offline(node_id: str, region: str) -> bool:
    text = f":red_circle: *Relay node offline* — `{node_id}` ({region})"
    return _send({"text": text, "channel": settings.relay_slack_channel})
