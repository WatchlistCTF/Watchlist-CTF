"""S3 service — artifact store operations."""

import boto3
import hashlib
import logging
from botocore import exceptions as botocore_exc
from botocore.config import Config
from typing import Optional
from urllib.parse import urlparse

from app.config import settings

logger = logging.getLogger(__name__)

BOTO_CONFIG = Config(
    connect_timeout=5,
    read_timeout=10,
    retries={"max_attempts": 2, "mode": "standard"},
)


def _parse_bucket(url: str) -> tuple[str, str]:
    """Parse bucket name and region from S3 URL."""
    parsed = urlparse(url)
    host = parsed.netloc  # nl-relay-artifacts-7c2a.s3.us-east-2.amazonaws.com
    parts = host.split(".")
    bucket = parts[0]
    # s3.us-east-2 or s3 (us-east-1 shorthand)
    region = parts[2] if len(parts) >= 4 and parts[1] == "s3" else "us-east-2"
    return bucket, region


def _client(region: Optional[str] = None):
    kwargs = {
        "config": BOTO_CONFIG,
        "region_name": region or settings.relay_aws_region,
    }
    if settings.relay_aws_key and settings.relay_aws_secret:
        kwargs["aws_access_key_id"] = settings.relay_aws_key
        kwargs["aws_secret_access_key"] = settings.relay_aws_secret
    return boto3.client("s3", **kwargs)


def validate_connection(artifact_url: str) -> bool:
    """Check the artifact store is reachable (anonymous HEAD)."""
    try:
        import urllib.request
        req = urllib.request.Request(artifact_url, method="HEAD")
        urllib.request.urlopen(req, timeout=5)
        return True
    except Exception as exc:
        logger.debug(f"Artifact store check failed: {exc}")
        # 403/redirect still means the host is up
        if hasattr(exc, "code") and exc.code in (403, 301, 302):
            return True
        return False


def list_artifacts(artifact_url: str) -> list[dict]:
    """List all objects in the artifact store bucket."""
    bucket, region = _parse_bucket(artifact_url)
    s3 = _client(region)
    objects = []
    try:
        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket):
            for obj in page.get("Contents", []):
                objects.append({
                    "key":           obj["Key"],
                    "size_bytes":    obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                    "etag":          obj["ETag"].strip('"'),
                })
    except botocore_exc.ClientError as exc:
        code = exc.response["Error"]["Code"]
        logger.error(f"S3 list failed [{code}]: {exc}")
        raise
    except botocore_exc.EndpointResolutionError as exc:
        logger.error(f"S3 endpoint error: {exc}")
        raise
    return objects


def upload_artifact(artifact_url: str, local_path: str, key: str) -> dict:
    """Upload a file to the artifact store."""
    bucket, region = _parse_bucket(artifact_url)
    s3 = _client(region)
    sha256 = hashlib.sha256(open(local_path, "rb").read()).hexdigest()
    try:
        s3.upload_file(
            local_path,
            bucket,
            key,
            ExtraArgs={"Metadata": {"sha256": sha256}},
        )
        logger.info(f"Uploaded {local_path} -> s3://{bucket}/{key}")
        return {"key": key, "sha256": sha256, "bucket": bucket}
    except botocore_exc.ClientError as exc:
        logger.error(f"Upload failed: {exc}")
        raise


def validate_checksums(artifact_url: str, manifest: list[dict]) -> list[dict]:
    """Validate artifact checksums against a manifest."""
    bucket, region = _parse_bucket(artifact_url)
    s3 = _client(region)
    results = []
    for entry in manifest:
        key      = entry["key"]
        expected = entry.get("sha256", "")
        try:
            head = s3.head_object(Bucket=bucket, Key=key)
            actual = head.get("Metadata", {}).get("sha256", "")
            match  = actual == expected if expected else None
            results.append({
                "key":      key,
                "expected": expected,
                "actual":   actual,
                "match":    match,
                "status":   "ok" if match else "mismatch" if match is False else "unknown",
            })
        except botocore_exc.ClientError as exc:
            results.append({"key": key, "status": "missing", "error": str(exc)})
    return results
