"""Application configuration — loaded from environment / .env file."""

from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    app_env: str = "development"
    log_level: str = "INFO"

    # Artifact store
    relay_artifacts: str = ""

    # Notifications
    relay_slack_webhook: str = ""
    relay_slack_channel: str = "#relay-ops"

    # Observability
    relay_sentry_dsn: str = ""

    # AWS (optional — falls back to instance profile / env vars)
    relay_aws_key: str = ""
    relay_aws_secret: str = ""
    relay_aws_region: str = "us-east-2"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
