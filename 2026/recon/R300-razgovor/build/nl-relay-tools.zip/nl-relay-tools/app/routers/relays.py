"""Relay node status endpoints."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

# Static relay registry — reflects the decommissioned estate
RELAY_REGISTRY: dict[str, dict] = {
    "relay-4cf34e": {
        "node_id":       "relay-4cf34e",
        "type":          "relay",
        "region":        "us-east-2",
        "status":        "decommissioned",
        "last_contact":  "2024-03-31T14:07:22Z",
        "decom_date":    "2024-03-31",
        "reason":        "scheduled",
    },
    "relay-7f3a2c": {
        "node_id":       "relay-7f3a2c",
        "type":          "relay",
        "region":        "eu-west-1",
        "status":        "decommissioned",
        "last_contact":  "2023-11-28T22:18:44Z",
        "decom_date":    "2023-11-28",
        "reason":        "unscheduled",
    },
    "relay-141786": {
        "node_id":       "relay-141786",
        "type":          "relay",
        "region":        "us-west-1",
        "status":        "decommissioned",
        "last_contact":  "2024-01-15T08:31:19Z",
        "decom_date":    "2024-01-15",
        "reason":        "directive-nl-2023-q4-07",
    },
    "relay-2b8e91": {
        "node_id":       "relay-2b8e91",
        "type":          "relay",
        "region":        "us-central",
        "status":        "decommissioned",
        "last_contact":  "2023-07-04T16:55:03Z",
        "decom_date":    "2023-07-04",
        "reason":        "classified",
    },
    "relay-5d0e44": {
        "node_id":       "relay-5d0e44",
        "type":          "relay",
        "region":        "us-east-1",
        "status":        "decommissioned",
        "last_contact":  "2026-08-01T09:44:11Z",
        "decom_date":    "2026-08-01",
        "reason":        "scheduled-retirement-q3-2026",
    },
    "relay-a3f819": {
        "node_id":       "relay-a3f819",
        "type":          "relay",
        "region":        "us-east-2",
        "status":        "quarantined",
        "last_contact":  "2023-02-11T11:00:47Z",
        "decom_date":    "2023-02-11",
        "reason":        "security-incident",
    },
    "feed-arc-0c44": {
        "node_id":       "feed-arc-0c44",
        "type":          "archive-feed",
        "region":        "us-central",
        "status":        "decommissioned",
        "last_contact":  "2022-09-30T07:47:55Z",
        "decom_date":    "2022-09-30",
        "reason":        "migrated-to-feed-secondary",
    },
    "feed-arc-3b1e": {
        "node_id":       "feed-arc-3b1e",
        "type":          "archive-feed",
        "region":        "us-west-2",
        "status":        "decommissioned",
        "last_contact":  "2022-06-14T19:03:22Z",
        "decom_date":    "2022-06-14",
        "reason":        "upstream-disconnection",
    },
    "proc-node-9f2a": {
        "node_id":       "proc-node-9f2a",
        "type":          "processing",
        "region":        "us-east-1",
        "status":        "hold",
        "last_contact":  "2026-07-22T14:19:08Z",
        "decom_date":    None,
        "reason":        "administrative-hold-pending-review",
    },
}


class RelayStatus(BaseModel):
    node_id:      str
    type:         str
    region:       str
    status:       str
    last_contact: Optional[str]
    decom_date:   Optional[str]
    reason:       Optional[str]


@router.get("/", summary="List all relay nodes")
async def list_relays(
    status: Optional[str] = None,
    region: Optional[str] = None,
):
    nodes = list(RELAY_REGISTRY.values())
    if status:
        nodes = [n for n in nodes if n["status"] == status]
    if region:
        nodes = [n for n in nodes if n["region"] == region]
    return {
        "count": len(nodes),
        "nodes": nodes,
    }


@router.get("/{node_id}", summary="Get relay node details", response_model=RelayStatus)
async def get_relay(node_id: str):
    node = RELAY_REGISTRY.get(node_id)
    if not node:
        raise HTTPException(status_code=404, detail=f"Relay node '{node_id}' not found")
    return node


@router.get("/{node_id}/artifacts", summary="List artifacts for a relay node")
async def relay_artifacts(node_id: str):
    from app.config import settings
    from app.services import s3 as s3_svc
    if not RELAY_REGISTRY.get(node_id):
        raise HTTPException(status_code=404, detail=f"Relay node '{node_id}' not found")
    if not settings.relay_artifacts:
        raise HTTPException(status_code=503, detail="Artifact store not configured")
    try:
        all_objects = s3_svc.list_artifacts(settings.relay_artifacts)
        node_objects = [o for o in all_objects if node_id in o["key"]]
        return {"node_id": node_id, "count": len(node_objects), "artifacts": node_objects}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))
