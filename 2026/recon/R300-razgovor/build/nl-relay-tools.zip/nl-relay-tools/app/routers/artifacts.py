"""Artifact management endpoints."""

from fastapi import APIRouter, HTTPException, UploadFile, File
from pydantic import BaseModel
from typing import Optional
import tempfile, os, logging

from app.config import settings
from app.services import s3 as s3_svc
from app.services.notify import notify_sync_complete, notify_validation_failure

logger = logging.getLogger(__name__)
router = APIRouter()


def _require_artifacts():
    if not settings.relay_artifacts:
        raise HTTPException(
            status_code=503,
            detail="Artifact store not configured. Set RELAY_ARTIFACTS in environment.",
        )


class ValidateRequest(BaseModel):
    manifest: list[dict]


class SyncResponse(BaseModel):
    uploaded: int
    errors:   int
    keys:     list[str]


@router.get("/", summary="List artifacts in the store")
async def list_artifacts():
    _require_artifacts()
    try:
        objects = s3_svc.list_artifacts(settings.relay_artifacts)
        return {
            "store":    settings.relay_artifacts,
            "count":    len(objects),
            "artifacts": objects,
        }
    except Exception as exc:
        logger.error(f"list_artifacts failed: {exc}")
        raise HTTPException(status_code=502, detail=f"Artifact store error: {exc}")


@router.post("/sync", summary="Upload a file to the artifact store",
             response_model=SyncResponse)
async def sync_artifact(
    node_id: str,
    file: UploadFile = File(...),
):
    _require_artifacts()
    key = f"media/{file.filename}"
    try:
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write(await file.read())
            tmp_path = tmp.name
        result = s3_svc.upload_artifact(settings.relay_artifacts, tmp_path, key)
        notify_sync_complete(node_id, count=1)
        return SyncResponse(uploaded=1, errors=0, keys=[result["key"]])
    except Exception as exc:
        logger.error(f"sync failed: {exc}")
        notify_sync_complete(node_id, count=0, errors=1)
        raise HTTPException(status_code=502, detail=str(exc))
    finally:
        if "tmp_path" in locals() and os.path.exists(tmp_path):
            os.unlink(tmp_path)


@router.post("/validate", summary="Validate artifact checksums against a manifest")
async def validate_artifacts(node_id: str, body: ValidateRequest):
    _require_artifacts()
    try:
        results  = s3_svc.validate_checksums(settings.relay_artifacts, body.manifest)
        failures = [r["key"] for r in results if r.get("status") != "ok"]
        if failures:
            notify_validation_failure(node_id, failures)
        return {
            "node_id":  node_id,
            "total":    len(results),
            "ok":       len(results) - len(failures),
            "failures": len(failures),
            "results":  results,
        }
    except Exception as exc:
        logger.error(f"validate failed: {exc}")
        raise HTTPException(status_code=502, detail=str(exc))


@router.get("/manifest", summary="Get the current artifact manifest")
async def get_manifest():
    _require_artifacts()
    try:
        objects = s3_svc.list_artifacts(settings.relay_artifacts)
        manifest = [
            {"key": o["key"], "size_bytes": o["size_bytes"], "sha256": ""}
            for o in objects
        ]
        return {"count": len(manifest), "manifest": manifest}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))
