EVIDENCE CACHE — compiled by M. Cole (the material P100 mislabeled "target research").

Read these together with the badge database and the audit log.

WHAT I FOUND
- Someone using the service account 'svc_export_04' has been bulk-exporting the
  Northern Lights subject dataset to an external relay. Those export lines in
  the audit log each carry a request signature (req_sig=...).
- That signature is not random. The building's access system signs every one
  of a person's badge events with the SAME per-device key (the session_token
  column). The export signatures were produced with that same key.
- So: whoever holds that device key made both the badge events AND the exports.

HOW TO PROVE WHO
- Each token is:  HMAC_SHA256( device_key , IDENTIFIER || timestamp )[:16 hex]
      badge event : IDENTIFIER = the cardholder's card_id
      export line : IDENTIFIER = the account name ('svc_export_04')
- One export fires at the EXACT timestamp of a restricted-level badge entry.
  Recompute both HMACs with the key below; if both match the values on record,
  the exporter shares the badge-holder's device key. Find whose card_id that is.
- The card_id encodes their 9-digit designation (AR-XXX-XX-XXXX).

RECOVERED DEVICE KEY (hex) — I lifted it from the access controller:
  7b1e0c9a4f2d6835a90e17c4bb52f6d38e4a1c07d9236f5b8a0e2c4471f9a6d3

worked check (the smoking gun):
  timestamp        = 2026-03-13T19:40:33
  badge card_id    = AR-304-77-1592
  export account   = svc_export_04
  -> HMAC(key, card_id||ts)[:16] should equal that badge row's session_token
  -> HMAC(key, 'svc_export_04'||ts)[:16] should equal that export line's req_sig
  if both hold, the exporter IS the badge holder.

Then decrypt his plan (pierce_plan.enc):
  key = SHA256( <Maya's designation from P100> || "SL2-MAIN" || sha256(exhibit_A.jpg) )
  format = nonce(12 bytes) || AES-256-GCM ciphertext
